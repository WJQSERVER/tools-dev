# WJQserver-tools-BETA
由WJQserver Studio推出的快捷Linux工具箱-测试版本

V.0.5 BETA
```
wget -O tools.sh https://raw.githubusercontent.com/WJQSERVER/tools-dev/main/tools.sh && chmod +x tools.sh && clear && ./tools.sh
```
V.0.4-fix1-dlc1 BETA-CN
```
wget -O tools-cn.sh https://tools.wjqserver.xyz/https://raw.githubusercontent.com/WJQSERVER/tools-dev/main/tools-cn.sh && chmod +x tools-cn.sh && clear && ./tools-cn.sh
```
# 声明

大部分功能非团队原创，部分功能仅提供辅助调用项目

不提供/保证任何功能的可用性，安全性，有效性，合法性

请确定你的用途符合 PRC(Mainland) USA 相关法律法规的要求和限制

请确定你的用途符合 你当地和运行环境/设备的 相关法律法规的要求和限制

DEV版本为开发版本,不推荐使用
BETA版本为测试版本,仅供测试使用

